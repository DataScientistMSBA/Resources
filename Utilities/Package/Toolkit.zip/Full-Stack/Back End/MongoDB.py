# coding: utf-8

# # [Official Documentation](https://www.mongodb.com/docs/)



def ComingSoon():
    print("Coming Soon")
    return

