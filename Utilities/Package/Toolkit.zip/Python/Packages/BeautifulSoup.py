# coding: utf-8

# # [Official Documentation](https://www.crummy.com/software/BeautifulSoup/bs4/doc/)



def ComingSoon():
    print("Coming Soon")
    return




get_ipython().run_line_magic('run', '"../Configuration/PackageLoader.ipynb"')

