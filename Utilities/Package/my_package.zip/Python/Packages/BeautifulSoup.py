# coding: utf-8

# # [Official Documentation](https://www.crummy.com/software/BeautifulSoup/bs4/doc/)



def ComingSoon():
    print("Coming Soon")
    return

