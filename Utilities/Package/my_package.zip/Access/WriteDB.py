# coding: utf-8



def ComingSoon():
    print("Coming Soon")
    return




def ComingSoon2():
    print("Coming Soon 2")
    return

