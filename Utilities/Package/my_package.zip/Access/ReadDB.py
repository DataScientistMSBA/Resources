# coding: utf-8



def ComingSoon():
    print("Coming Soon")
    return

